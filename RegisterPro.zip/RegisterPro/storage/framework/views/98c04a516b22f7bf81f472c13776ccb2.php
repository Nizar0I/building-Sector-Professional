<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KHADAMATI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="css/style2.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <div class="navbar">
        <div class="logo">KHADAMATI</div>
        <div class="search-bar">
            <input type="text" placeholder="search">
            <button class="search-button"><i class="fas fa-search"></i></button>
        </div>
        <div class="buttons">
            <a href="/" class="logout">LOGOUT</a>
        </div>
    </div>

    <div class="container py-5">
        <h1 class="text-center welcome-title">bienvenu dans notre site khadamati</h1>

        <!-- <h1 class="text-center">bienvenu dans khadamati</h1> -->
        <div class="row row-cols-1 row-cols-md-3 g-4 py-5">

            <!-- Electricien -->
            <div class="col profession electricien">
                <div class="card">
                    <img src="./img/elec1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Mohammed chihab</h5>
                        <p class="card-text">Bonjour, je m'appelle Mohammed chihab, électricien qualifié avec 6 ans d'expérience. Je suis spécialisé dans l'installation, la maintenance, et le dépannage des systèmes électriques, en garantissant un service fiable et sécurisé pour tous vos besoins.</p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Electricien</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>

            <div class="col profession climatisation">
                <div class="card">
                    <img src="./img/clim3.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Amin Mouha</h5>
                        <p class="card-text">Bonjour, je m'appelle Amin Mouha, spécialiste en climatisation ,J'excelle dans l'installation, l'entretien et la réparation des systèmes de climatisation, en assurant un confort optimal et une performance énergétique maximale pour votre espace.
                            <br><br>
                        </p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Climatisation</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>

            <div class="col profession plombier">
                <div class="card">
                    <img src="./img/plambier1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Mounir Nokib</h5>
                        <p class="card-text">Bonjour, je m'appelle Mounir Nokib, plombier avec 7 ans d'expérience. Je suis expert en installation, réparation et entretien de systèmes de plomberie, et je m'engage à offrir un service rapide, fiable et de haute qualité pour tous vos besoins en plomberie.</p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Plombier</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>

            <div class="col profession climatisation">
                <div class="card">
                    <img src="./img/clim2.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Ilyas kikab</h5>
                        <p class="card-text">Bonjour, je suis Ilyas kikab, expert en climatisation avec 5 ans d'expérience.
                             Je me spécialise dans l'installation, la maintenance et la réparation des systèmes de climatisation, en assurant un confort durable et une efficacité énergétique pour vos espaces.</p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>climatisation</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>

            <div class="col profession menuisier">
                <div class="card">
                    <img src="./img/menui2.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Hassan Bannou</h5>
                        <p class="card-text">Bonjour, je m'appelle Hassan Bannou, menuisier qualifié avec 10 ans d'expérience.Je suis spécialisé dans la création, la réparation et l'installation de meubles et menuiseries sur mesure, en offrant des finitions de haute qualité et un service personnalisé pour répondre à vos besoins.</p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Menuisier</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>

            <div class="col profession electricien">
                <div class="card">
                    <img src="./img/elec2.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Youness Akkou</h5>
                        <p class="card-text">Bonjour, je suis Youness Akkou, électricien expérimenté avec 6 ans dans le domaine.Je me spécialise dans l'installation et le dépannage de systèmes électriques, en garantissant des solutions sécurisées, efficaces et adaptées à vos besoins.
                            <br><br>
                        </p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Electricien</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>
<!-- --------------------------------------------------------------- -->
            <div class="col profession plombier ">
                <div class="card">
                    <img src="./img/2.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Khalil chari</h5>
                        <p class="card-text">Bonjour, je suis Khalil chari, plombier avec 9 ans d'expérience. Je me spécialise dans l'installation, l'entretien et la réparation de systèmes de plomberie, en offrant des solutions rapides, fiables et adaptées à chaque situation.
                            <br><br>
                        </p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Plombier</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>
            <div class="col profession menuisier ">
                <div class="card">
                    <img src="./img/menuis1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Fahd Kourdah</h5>
                        <p class="card-text">Bonjour, je suis Fahd Kourdah, menuisier avec 8 ans d'expérience.Je me spécialise dans la fabrication, l'installation et la rénovation de menuiseries sur mesure, en créant des pièces uniques qui allient esthétique et fonctionnalité.
                            <br><br>
                            </p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Menuisier</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>

            <div class="col profession electricien">
                <div class="card">
                    <img src="./img/electri3.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Mouad ifak</h5>
                        <p class="card-text">Bonjour, je suis Mouad ifak, électricien avec 9 ans d'expérience. Je me spécialise dans l'installation et la réparation de systèmes électriques, en garantissant des solutions fiables, performantes, et sur mesure pour répondre à vos besoins.
                            <br><br>
                        </p>
                    </div>
                    <div class="mb-5 d-flex justify-content-around">
                        <h3>Electricien</h3>
                        <button class="btn btn-primary" onclick="document.querySelector('.hidden-link').click();">Reserver</button>
                        <a href="/Reservation2" class="hidden-link">Reserver</a>
                    </div>
                </div>
            </div>



        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>


    <!-- footer -->
    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href=""><i class="fa-brands fa-facebook"></i></a>
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-google-plus"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
            </div>
            <div class="footerNav">
                <ul><li><a href="">Home</a></li>
                    <li><a href="">News</a></li>
                    <li><a href="">About</a></li>
                    <li><a href="">Contact Us</a></li>
                    <li><a href="">our Team</a></li>
                </ul>
            </div>

        </div>
        <div class="footerBottom">
            <p>Copyright &copy;2024; Designed by <span class="designer">Lalaoui</span></p>
        </div>
    </footer>

    <script>
        document.querySelector('.search-button').addEventListener('click', function() {
            // Get the search input value and convert it to lowercase for case-insensitive matching
            let searchInput = document.querySelector('.search-bar input').value.toLowerCase();
            // Select all elements with the class 'profession'
            let professions = document.querySelectorAll('.profession');

            // Loop through each profession and check if it matches the search input
            professions.forEach(function(profession) {
                // Get the profession title text and convert it to lowercase
                let professionText = profession.querySelector('h3').textContent.toLowerCase();
                // Check if the search input is found within the profession title
                if (professionText.includes(searchInput)) {
                    // If a match is found, display the profession
                    profession.style.display = 'block';
                } else {
                    // If no match is found, hide the profession
                    profession.style.display = 'none';
                }
            });
        });
    </script>

</body>
</html>
<?php /**PATH C:\xampp2\htdocs\RegisterPro\resources\views/index2.blade.php ENDPATH**/ ?>