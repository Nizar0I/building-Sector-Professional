<?php $__env->startSection('title', 'Form reservation'); ?>

<?php $__env->startSection('contents'); ?>
  <form action="<?php echo e(isset($reservation) ? route('reservation.update', $reservation->id) : route('reservation.save')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
      <div class="col-12">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(isset($reservation) ? 'Form Edit reservation' : 'Form add reservation'); ?></h6>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label for="nama">Name reservation</label>
              <input type="text" class="form-control" id="name" name="name" value="<?php echo e(isset($reservation) ? $reservation->name : ''); ?>">
            </div>
            <div class="form-group">
                <label for="nama">Email</label>
                <input type="text" class="form-control" id="email" name="email" value="<?php echo e(isset($reservation) ? $reservation->email : ''); ?>">
              </div>
              <div class="form-group">
                <label for="nama">Adresse</label>
                <input type="text" class="form-control" id="adresse" name="adresse" value="<?php echo e(isset($reservation) ? $reservation->adresse : ''); ?>">
              </div>
              <div class="form-group">
                <label for="nama">Telephone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e(isset($reservation) ? $reservation->telephone : ''); ?>">
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\RegisterPro\resources\views/reservation/form.blade.php ENDPATH**/ ?>