<!DOCTYPE html>
<!-- Designined by CodingLab - youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Réservation </title>
    <link rel="stylesheet" href="css/reservation2.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Réservation</div>
    <div class="content">
        <form action="<?php echo e(route('storereservation')); ?>" method="POST">
            <?php echo csrf_field(); ?>

        <div class="user-details">
          <div class="input-box">
            <span class="details">Nom complet</span>
            <input type="text" name="name" id="name" placeholder="Entrer votre nom complet" required>
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" name="emeil" id="emeil"placeholder="Entrer votre email" required>
          </div>
          <div class="input-box">
            <span class="details">Numéro de téléphone</span>
            <input type="text" name="telephone" id="telephone" placeholder="Entrer votre Numéro" required>
          </div>
          <div class="input-box">
            <span class="details">Ville</span>
            <input type="text" name="ville" id="ville" placeholder="Entrer votre Ville" required>
          </div>


          <div class="input-box">
            <span class="details">Options</span>
            <select name="option" id="option">
                <option value="">veuiller chosir une option</option>

                <option value="Climatisation">Climatisation</option>
                <option value="plomberie">plomberie</option>
                <option value="Électricité">Électricité</option>
                <option value="Menuiserie">Menuiserie</option>

              </select>

          </div>


          <div class="input-box">
            <span class="details">caractéristique du problème</span>
            <textarea name="caracteristique" id="caracteristique" rows="5" cols="33">

              </textarea>
          </div>

        </div>
        <div class="button">
          <input type="submit" value="reservation">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
<?php /**PATH C:\xampp2\htdocs\RegisterPro\resources\views//reservation2.blade.php ENDPATH**/ ?>