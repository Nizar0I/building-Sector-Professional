 
<?php $__env->startSection('title', 'Data reservations'); ?>
 
<?php $__env->startSection('contents'); ?>
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data reservations</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>Name </th>
              <th>email</th>
              <th>telephone</th>
              <th>ville</th>
              <th>option</th>
              <th>caracteristique</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php ($no = 1); ?>
            <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($no++); ?></th>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->telephone); ?></td>
                <td><?php echo e($row->ville); ?></td>
                <td><?php echo e($row->option); ?></td>
                <td><?php echo e($row->caracteristique); ?></td>

                <td>
                  <a href="<?php echo e(route('reservation.edit', $row->id)); ?>" class="btn btn-warning">Edit</a>
                  <a href="<?php echo e(route('reservation.delete', $row->id)); ?>" class="btn btn-danger">Delete</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\RegisterPro\resources\views/reservation/index.blade.php ENDPATH**/ ?>