<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="css/style.css">


    <title>KHADAMATI</title>
</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="70">

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg py-3 sticky-top navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img class="logo" src="images/" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#services">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Caracterestique</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/logine">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/registere">Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contacter nous</a>
                    </li>
                </ul>
                <a href="<?php echo e(route('createprofess')); ?>" class="btn btn-primary ms-lg-3" >devenir Prefessionnel</a>
            </div>
        </div>
    </nav><!-- //NAVBAR -->

    <!-- HERO -->
    <div class="hero vh-100 d-flex align-items-center" id="home">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 mx-auto text-center">
                    <h1 class="display-4 text-white">KHADAMATI</h1>
                    <p class="text-white my-3">Le site Khadamati facilite le processus de recherche et de réservation de services <br>de professionnels du bâtiment pour des besoins spécifiques. </p>
                    <a href="file:///C:/Users/nizar/OneDrive/Bureau/Projet%20Uber/login%20template/Nouveau%20dossier/index.html" class="btn me-2 btn-primary">Get Started</a>
                    <a href="file:///C:/Users/nizar/OneDrive/Bureau/Projet%20Uber/Register/index.html" class="btn btn-outline-light">Register</a>
                </div>
            </div>
        </div>
    </div><!-- //HERO -->

    <!-- SERVICES -->
    <section id="services">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-8 mx-auto text-center">
                    <h6 class="text-primary">SERIVCES</h6>
                    <h1>Nos services</h1>
                    <p>"Khadamati" est notre priorité absolue. Nous nous engageons à offrir une plateforme d'intégration sûre, confortable et pratique pour répondre à tous vos besoins professionnels dans le secteur du bâtiment. Voici les services que nous offrons :</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-sm-6">
                    <div class="service card-effect bounceInUp">
                        <div class="iconbox">
                            <i class='bx bxs-check-shield'></i>
                        </div>
                        <h5 class="mt-4 mb-2">Promotion de l'expertise</h5>
                        <p> Visibilité renforcée pour les professionnels grâce à la mise en avant de leurs compétences.
                            <br><br><br>
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="service card-effect">
                        <div class="iconbox">
                            <i class='bx bxs-comment-detail'></i>
                        </div>
                        <h5 class="mt-4 mb-2">Flexibilité</h5>
                        <p> Nos services sont adaptés à vos besoins, que ce soit pour des interventions d'urgence, des projets de longue durée ou des demandes spécifiques.
                            <br><br> </p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="service card-effect">
                        <div class="iconbox">
                            <i class='bx bxs-cog'></i>
                        </div>
                        <h5 class="mt-4 mb-2">L'Assistance Clientèle</h5>
                        <p> Notre équipe est disponible à tout moment pour répondre à vos questions et résoudre vos problèmes.<br><br><br></p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="service card-effect">
                        <div class="iconbox">
                            <i class='bx bxs-heart'></i>
                        </div>
                        <h5 class="mt-4 mb-2">Consultation des profils détaillés</h5>
                        <p>Possibilité de consulter les profils détaillés des professionnels, y compris leurs compétences, leurs certifications et leurs réalisations antérieures. <br><br> </p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="service card-effect">
                        <div class="iconbox">
                            <i class='bx bxs-rocket'></i>
                        </div>
                        <h5 class="mt-4 mb-2">Gestion des Demandes</h5>
                        <p> permettant aux utilisateurs de soumettre facilement leurs demandes de services spécifiques, puis de suivre leur état d'avancement jusqu'à leur résolution. <br><br></p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="service card-effect">
                        <div class="iconbox">
                            <i class='bx bxs-doughnut-chart'></i>
                        </div>
                        <h5 class="mt-4 mb-2">Diversité des professionnels</h5>
                        <p>Une large gamme de professionnels disponibles sur notre plateforme Khadamati les électriciens, les plombiers, climatisation, les maçons, les architectes, les décorateurs d'intérieur... .<br></p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- SERVICES -->

    <!-- FEATURES -->
    <section class="row w-100 py-0 bg-light" id="features">
        <div class="col-lg-6 col-img"></div>
        <div class="col-lg-6 py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 offset-md-1">
                        <h6 class="text-primary">Pourquoi nous</h6>
                        <h1>Notre Caracterestique</h1>


                        <div class="feature d-flex mt-5">
                            <div class="iconbox me-3">
                                <i class='bx bxs-comment-edit'></i>
                            </div>
                            <div>
                                <h5>Disponibilité 24/7</h5>
                                <p>  Offrant une assistance et des services à toute heure du jour , garantissant une réponse rapide aux besoins des utilisateurs à tout moment. </p>
                            </div>
                        </div>
                        <div class="feature d-flex">
                            <div class="iconbox me-3">
                                <i class='bx bxs-user-circle'></i>
                            </div>
                            <div>
                                <h5>Trouvez des professionnels qualifiés rapidement</h5>
                                <p>Notre plateforme Khadamati vous permet de trouver et de contacter rapidement un professionnel pour répondre à vos besoins, en quelques clics seulement </p>
                            </div>
                        </div>
                        <div class="feature d-flex">
                            <div class="iconbox me-3">
                                <i class='bx bxs-download'></i>
                            </div>
                            <div>
                                <h5> Choix de professionnels</h5>
                                <p>Notre plateforme propose une diversité de professionnels dans le secteur du bâtiment, offrant ainsi aux utilisateurs une gamme étendue d'options pour répondre à leurs besoins spécifiques en matière de travaux et de services.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section><!-- FEATURES -->

    <!-- TEAM -->
   <!-- <section id="team">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-8 mx-auto text-center">
                    <h6 class="text-primary">TEAM</h6>
                    <h1>Meet Our Crew Members</h1>
                    <p>Lorem ipsum dolor sit amet consectetur nisi necessitatibus repellat distinctio eveniet eaque fuga
                        in cumque optio consectetur harum vitae debitis sapiente praesentium aperiam aut</p>
                </div>
            </div>
            <div class="row text-center g-4">
                <div class="col-lg-3 col-sm-6">
                    <div class="team-member card-effect">
                        <img src="img/team1.jpg" alt="">
                        <h5 class="mb-0 mt-4">Sharbat Khan</h5>
                        <p>Web Developer</p>
                        <div class="social-icons">
                            <a href="#"><i class='bx bxl-facebook'></i></a>
                            <a href="#"><i class='bx bxl-twitter'></i></a>
                            <a href="#"><i class='bx bxl-instagram-alt'></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="team-member card-effect">
                        <img src="img/team2.jpg" alt="">
                        <h5 class="mb-0 mt-4">Sharbat Khan</h5>
                        <p>Web Developer</p>
                        <div class="social-icons">
                            <a href="#"><i class='bx bxl-facebook'></i></a>
                            <a href="#"><i class='bx bxl-twitter'></i></a>
                            <a href="#"><i class='bx bxl-instagram-alt'></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="team-member card-effect">
                        <img src="img/team3.jpg" alt="">
                        <h5 class="mb-0 mt-4">Sharbat Khan</h5>
                        <p>Web Developer</p>
                        <div class="social-icons">
                            <a href="#"><i class='bx bxl-facebook'></i></a>
                            <a href="#"><i class='bx bxl-twitter'></i></a>
                            <a href="#"><i class='bx bxl-instagram-alt'></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="team-member card-effect">
                        <img src="img/team4.jpg" alt="">
                        <h5 class="mb-0 mt-4">Sharbat Khan</h5>
                        <p>Web Developer</p>
                        <div class="social-icons">
                            <a href="#"><i class='bx bxl-facebook'></i></a>
                            <a href="#"><i class='bx bxl-twitter'></i></a>
                            <a href="#"><i class='bx bxl-instagram-alt'></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>  -->





    <!-- CONTACT -->
    <section id="contact">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-8 mx-auto text-center">
                    <h6 class="text-primary">CONTACTE</h6>
                    <h1>Entre en contact</h1>
                    <p>vous pouvez nous contacter de toute question ou probleme,et vous receverez une reponse plus tard</p>
                </div>
            </div>

            <form action="" class="row g-3 justify-content-center">
                <div class="col-md-5">
                    <input type="text" class="form-control" placeholder="Nom complet">
                </div>
                <div class="col-md-5">
                    <input type="text" class="form-control" placeholder="Enter E-mail">
                </div>
                <div class="col-md-10">
                    <input type="text" class="form-control" placeholder="Enter Sujet">
                </div>
                <div class="col-md-10">
                    <textarea name="" id="" cols="30" rows="5" class="form-control"
                        placeholder="Enter Message"></textarea>
                </div>
                <div class="col-md-10 d-grid">
                    <button class="btn btn-primary">Contacte</button>
                </div>
            </form>

        </div>
    </section><!-- CONTACT -->

</body>
</html>

<?php /**PATH C:\xampp2\htdocs\RegisterPro\resources\views/index.blade.php ENDPATH**/ ?>