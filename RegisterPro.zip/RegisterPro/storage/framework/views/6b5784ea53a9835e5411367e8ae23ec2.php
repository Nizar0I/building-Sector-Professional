<?php $__env->startSection('title', 'Data product'); ?>

<?php $__env->startSection('contents'); ?>
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data product</h6>
    </div>
    <div class="card-body">
            <?php if(auth()->user()->level == 'Admin'): ?>
      <a href="<?php echo e(route('products.add')); ?>" class="btn btn-primary mb-3">Add product</a>
            <?php endif; ?>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>code product</th>
              <th>name product</th>
              <th>Category</th>
              <th>Price</th>
                            <?php if(auth()->user()->level == 'Admin'): ?>
              <th>Action</th>
                            <?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php ($no = 1); ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($no++); ?></th>
                <td><?php echo e($row->item_code); ?></td>
                <td><?php echo e($row->productname); ?></td>
                <td><?php echo e($row->category); ?></td>
                <td><?php echo e($row->price); ?></td>
                                <?php if(auth()->user()->level == 'Admin'): ?>
                <td>
                  <a href="<?php echo e(route('products.edit', $row->id)); ?>" class="btn btn-warning">Edit</a>
                  <a href="<?php echo e(route('products.delete', $row->id)); ?>" class="btn btn-danger">Delete</a>
                </td>
                                <?php endif; ?>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\RegisterPro\resources\views/products/index.blade.php ENDPATH**/ ?>