<?php

use App\Http\Controllers\ProfessController;
use App\Http\Controllers\ProfileController;
use App\Models\Profess;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ReservationController;


// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/Reservation2', function () {
        return view('Reservation2');
    });

    Route::get('/index2', function () {
        return view('index2');
    });

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

Route::get('/', function () {
    return view('index');
});

Route::controller(AuthController::class)->group(function () {
    Route::get('registere', 'registere')->name('registere');
    Route::post('registere', 'registereSave')->name('registere.save');

    Route::get('logine', 'logine')->name('logine');
    Route::post('logine', 'logineAction')->name('logine.action');

    Route::get('logout', 'logout')->middleware('auth')->name('logout');
});

Route::middleware('auth')->group(function () {
    Route::get('dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::controller(ProductController::class)->prefix('products')->group(function () {
        Route::get('', 'index')->name('products');
        Route::get('add', 'add')->name('products.add');
        Route::post('add', 'save')->name('products.save');
        Route::get('edit/{id}', 'edit')->name('products.edit');
        Route::post('edit/{id}', 'update')->name('products.update');
        Route::get('delete/{id}', 'delete')->name('products.delete');
    });

    Route::controller(CategoryController::class)->prefix('category')->group(function () {
        Route::get('', 'index')->name('category');
        Route::get('add', 'add')->name('category.add');
        Route::post('save', 'save')->name('category.save');
        Route::get('edit/{id}', 'edit')->name('category.edit');
        Route::post('edit/{id}', 'update')->name('category.update');
        Route::get('delete/{id}', 'delete')->name('category.delete');
    });

    Route::controller(ProfessController::class)->prefix('profess')->group(function () {
        Route::get('', 'index')->name('profess');
        // Route::get('add', 'add')->name('profess.add');
        // Route::post('save', 'save')->name('profess.save');
        Route::get('edit/{id}', 'edit')->name('profess.edit');
        Route::post('edit/{id}', 'update')->name('profess.update');
        Route::get('delete/{id}', 'delete')->name('profess.delete');
    });

    Route::controller(UserController::class)->prefix('user')->group(function () {
        Route::get('', 'index')->name('user');
        // Route::get('add', 'add')->name('user.add');
        // Route::post('save', 'save')->name('user.save');
        Route::get('edit/{id}', 'edit')->name('user.edit');
        Route::post('edit/{id}', 'update')->name('user.update');
        Route::get('delete/{id}', 'delete')->name('user.delete');
    });

    Route::controller(ReservationController::class)->prefix('reservation')->group(function () {
        Route::get('', 'index')->name('reservation');
        Route::get('/addReservation',[ReservationController::class,'create'])->name('createReservation');
        Route::post('/storeReservation',[ReservationController::class,'store'])->name('storereservation');
        // Route::get('add', 'add')->name('reservation.add');
        // Route::post('save', 'save')->name('reservation.save');
        Route::get('edit/{id}', 'edit')->name('reservation.edit');
        Route::post('edit/{id}', 'update')->name('reservation.update');
        Route::get('delete/{id}', 'delete')->name('reservation.delete');
    });
});

Route::get('/addProfess',[ProfessController::class,'create'])->name('createprofess');
Route::post('/storeProfess',[ProfessController::class,'store'])->name('storeprofess');

