<?php

namespace App\Http\Controllers;
use App\Models\Profess;
use Illuminate\Http\Request;

class ProfessController extends Controller
{
    public function create(){
        return view('profess.addprofess');
    }

      /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        Profess::create($input);
        return redirect('/');
    }

    // public function showall()
    // {
    //     $professs = Profess::all();
    //     return view('profess.allprofess', compact('professs'));
    // }

    // public function edit($id){
    //     $profess = Profess::find($id);
    //     return $profess;
    // }

    // public function update(Request $request, $id){
    //     $profess = Profess::find($id);
    //     $profess->update($request->all());
    //     return redirect()->route('allprofess');
    // }


    // public function destroy($id)
    // {
    //     $profess = Profess::find($id);
    //     $profess->delete();
    //     return redirect()->route('allprofess')->with('success', 'Room deleted successfully.');
    // }
    public function edit($id)
    {
        $profess = profess::find($id);
        //echo "$profess";
        return view('profess.form', ['profess' => $profess]);
    }

    public function update($id, Request $request)
    {
        $profess = Profess::find($id);
        $profess->update($request->all());

        return redirect()->route('profess');
    }

    public function delete($id)
    {
        profess::destroy($id);
        return redirect()->route('profess');
    }


    public function index()
    {
        $profess = profess::get();

        return view('profess/index', ['profess' => $profess]);
    }

}
