<?php

namespace App\Http\Controllers;
use App\Models\Reservation;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    public function create(){
        return view('reservation.addreservation');
    }

      /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        Reservation::create($input);
        return redirect('/');
    }

    // public function showall()
    // {
    //     $peservations = Peservation::all();
    //     return view('peservation.allpeservation', compact('peservations'));
    // }

    // public function edit($id){
    //     $peservation = Peservation::find($id);
    //     return $peservation;
    // }

    // public function update(Request $request, $id){
    //     $peservation = Peservation::find($id);
    //     $peservation->update($request->all());
    //     return redirect()->route('allpeservation');
    // }


    // public function destroy($id)
    // {
    //     $peservation = Peservation::find($id);
    //     $peservation->delete();
    //     return redirect()->route('allpeservation')->with('success', 'Room deleted successfully.');
    // }
    public function edit($id)
    {
        $reservation = reservation::find($id);
        //echo "$reservation";
        return view('reservation.form', ['reservation' => $reservation]);
    }

    public function update($id, Request $request)
    {
        $reservation = Reservation::find($id);
        $reservation->update($request->all());

        return redirect()->route('reservation');
    }

    public function delete($id)
    {
        reservation::destroy($id);
        return redirect()->route('reservation');
    }


    public function index()
    {
        $reservation = reservation::get();

        return view('reservation/index', ['reservation' => $reservation]);
    }
}
