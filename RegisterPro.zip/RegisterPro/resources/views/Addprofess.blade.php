{{-- <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel 10 Custom Login and Registration - Register Page</title>
    <link rel="stylesheet" href="{{ asset('css/add.css') }}">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <div class="title">Registration</div>
        <div class="content">
          <form action="add" Methode="POST">
            @csrf
            <div class="user-details">
              <div class="input-box">
                <span class="details">Nom Complet</span>
                <input type="text" value="{{(isset($profess))? $profess->Nom_complet : ''}}" name="Nom_complet"  placeholder="Enter your name" required>
              </div>
              <div class="input-box">
                <span class="details">Email</span>
                <input type="text" value="{{(isset($profess))? $profess->Email : ''}}" name="Email" placeholder="Enter your email" required>
              </div>
              <div class="input-box">
                <span class="details">Adresse</span>
                <input type="text" value="{{(isset($profess))? $profess->Adresse : ''}}" name="Adresse" placeholder="Enter your City" required>
              </div>
              <div class="input-box">
                <span class="details">Numero Telephone</span>
                <input type="text" value="{{(isset($profess))? $profess->telephone : ''}}" name="Telephone" placeholder="Enter your number" required>
              </div>

              <div class="input-box">
                <span class="details"> Password</span>
                <input type="text" value="{{(isset($profess))? $profess->password : ''}}" name="Password"  placeholder="Confirm your password" required>
              </div>
              <div class="input-box">
                <span class="details"> Experience</span>
                <textarea id="Exper" value="{{(isset($profess))? $profess->Experience : ''}}" name="Experience" rows="5" cols="33">
                  </textarea>
              </div>
            </div>
            <div class="button">
              <input type="submit" value="Register">
            </div>
          </form>
        </div>
      </div>
</body>
</html> --}}
