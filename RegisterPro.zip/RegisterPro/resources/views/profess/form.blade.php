@extends('layouts.app')

@section('title', 'Form profess')

@section('contents')
  <form action="{{ isset($profess) ? route('profess.update', $profess->id) : route('profess.save') }}" method="post">
    @csrf
    <div class="row">
      <div class="col-12">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{ isset($profess) ? 'Form Edit profess' : 'Form add profess' }}</h6>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label for="nama">Name profess</label>
              <input type="text" class="form-control" id="name" name="name" value="{{ isset($profess) ? $profess->name : '' }}">
            </div>
            <div class="form-group">
                <label for="nama">Email</label>
                <input type="text" class="form-control" id="email" name="email" value="{{ isset($profess) ? $profess->email : '' }}">
              </div>
              <div class="form-group">
                <label for="nama">Adresse</label>
                <input type="text" class="form-control" id="adresse" name="adresse" value="{{ isset($profess) ? $profess->adresse : '' }}">
              </div>
              <div class="form-group">
                <label for="nama">Telephone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" value="{{ isset($profess) ? $profess->telephone : '' }}">
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </div>
  </form>
@endsection
