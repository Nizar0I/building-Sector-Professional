@extends('layouts.app')
 
@section('title', 'Data professionnels')
 
@section('contents')
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data professionnels</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>Name profess</th>
              <th>email</th>
              <th>adresse</th>
              <th>telephone</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @php($no = 1)
            @foreach ($profess as $row)
              <tr>
                <th>{{ $no++ }}</th>
                <td>{{ $row->name }}</td>
                <td>{{ $row->email }}</td>
                <td>{{ $row->adresse }}</td>
                <td>{{ $row->telephone }}</td>
                <td>
                  <a href="{{ route('profess.edit', $row->id) }}" class="btn btn-warning">Edit</a>
                  <a href="{{ route('profess.delete', $row->id) }}" class="btn btn-danger">Delete</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection
