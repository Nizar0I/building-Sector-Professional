<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel 10 Custom Login and Registration - Register Page</title>
    <link rel="stylesheet" href="{{ asset('css/add.css') }}">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</head>
<body>
<body>
    <div class="container">
      <div class="title">Registration Professionnel</div>
      <div class="content">
        <form action="{{ route('storeprofess') }}" method="POST">
            @csrf
          <div class="user-details">
            <div class="input-box">
              <span class="details">Nom Complet</span>
              <input type="text"  name="name" id="name" required>
            </div>
            <div class="input-box">
              <span class="details">Email</span>
              <input type="email" name="email" id="email"  required>
            </div>
            <div class="input-box">
                <span class="details">Adresse</span>
                <input type="text" id="adresse" name="adresse" required>
              </div>
            <div class="input-box">
              <span class="details">Phone Number</span>
              <input type="tel"  id="telephone" name="telephone" required>
            </div>
            <div class="input-box">
              <span class="details">Password</span>
              <input type="password" id="password" name="password" required>
            </div>
            <div class="input-box">
              <span class="details">Experience</span>

              <textarea id="experience" name="experience" rows="5" cols="33" required>

            </textarea>
            </div>
          </div>

          <div class="button">
            <input type="submit" value="Register">
          </div>
        </form>
      </div>
    </div>
  </body>
</html>
